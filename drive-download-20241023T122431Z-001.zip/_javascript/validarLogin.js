function verificarJogador() {
    const nomeRegex = /^[a-zA-Z\s]+$/;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const telefoneRegex = /^\([1-9]{2}\) (?:[2-8]|9[0-9])[0-9]{3}\-[0-9]{4}$/;
  
    const nome = document.getElementById("nome").value;
    const email = document.getElementById("email").value;
    const telefone = document.getElementById("telefone").value;

  
  
    if (!nomeRegex.test(nome)) {
      alert("Nome inválido.Use apenas letras e espaços.");
      return false;
    }
  
    if (!telefoneRegex.test(telefone)) {
      alert("Número de telefone inválido. Use este formato: (00) 00000-0000.");
      return false;
    }
  
    
  
    if (!emailRegex.test(email)) {
      alert("E-mail inválido. Insira um e-email inválido.");
      return false;
    }
    return true;
  }
  