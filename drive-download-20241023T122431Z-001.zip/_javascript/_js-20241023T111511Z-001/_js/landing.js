let slideIndex = 0;
let slideWidth;
const slides = document.querySelectorAll('.carousel-slide img');
const slideContainer = document.querySelector('.carousel-slide');

// Inicializar o carrossel assim que a página carregar completamente
window.onload = function() {
    slideWidth = slides[0].clientWidth;  // Captura a largura da primeira imagem
    updateSlide();  // Posiciona corretamente o carrossel ao carregar
};

// Função para mover o carrossel para frente ou para trás
function moveSlide(n) {
    slideIndex += n;
    if (slideIndex >= slides.length) {
        slideIndex = 0;  // Se passar da última imagem, volta à primeira
    } else if (slideIndex < 0) {
        slideIndex = slides.length - 1;  // Se voltar antes da primeira, vai para a última
    }
    updateSlide();  // Atualiza a posição do carrossel
}

// Função para atualizar a posição do carrossel
function updateSlide() {
    slideContainer.style.transform = `translateX(${-slideIndex * slideWidth}px)`;  // Move o container de acordo com o índice atual
}

// Listener para redimensionamento da janela
window.onresize = function() {
    slideWidth = slides[0].clientWidth;  // Recalcula a largura da imagem ao redimensionar
    updateSlide();  // Reposiciona o carrossel após o redimensionamento
};
